# Bracu-Food-Mart
CSE370-DATABASE SYSTEMS-project
Bracu Food Mart is an online food ordering and delivery platform.

# Features
- User registration and login
- Menu selection and ordering
- Order tracking
- Payment integration
- Delivery management
- Admin panel for managing the menu and order

# Contributing
We welcome contributions to this project. If you would like to contribute, please fork the repository and submit a pull request with your changes.

# Demonstration Video
<a href="https://www.youtube.com/watch?v=bmy_G6ZDkIo">Click here </a>
